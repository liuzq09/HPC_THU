#include<stdlib.h>
#include<stdio.h>
#include<sys/time.h>
#define N 512 
int main(int argc, char *argv[])
{
    int i,j;
    double A[N][N];
    double t1,t2;
    struct timeval tv;
    gettimeofday(&tv, (struct timezone *)0);
    t1=tv.tv_sec+(double)tv.tv_usec*1e-6;

    for(i=0;i<N;i++)
	for(j=0;j<N;j++)
	    A[i][j]=1.0;
    gettimeofday(&tv, (struct timezone *)0);
    t2=tv.tv_sec+(double)tv.tv_usec*1e-6;
    printf("Elapsed time is %f\n", t2-t1);
    return 0;
}
