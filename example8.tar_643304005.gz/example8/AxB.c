#include<stdio.h>
#include<sys/time.h>
#include<sys/resource.h>
#define N 512 
void
gettime(double *cpu, double *wall)
{
    struct timeval tv;
    struct rusage ru;
    if (cpu != NULL) {
	getrusage(RUSAGE_SELF, &ru);
	*cpu = ru.ru_utime.tv_sec + (double)ru.ru_utime.tv_usec * 1e-6;
    }
    if (wall != NULL) {
	gettimeofday(&tv, NULL);
	*wall = tv.tv_sec + (double)tv.tv_usec * 1e-6;
    }
}

int main(int argc, char *argv[])
{
    int i,j,k;
    double A[N][N],B[N][N],C[N][N];
    double cpu0, cpu1, wall0, wall1;

    for(i=0;i<N;i++)
	for(j=0;j<N;j++){
	    A[i][j]=1.0;
	    B[i][j]=1.0;
	    C[i][j]=0.0;
	}

    gettime(&cpu0,&wall0);
    
    for(i=0;i<N;i++)
	for(j=0;j<N;j++)
	    for(k=0;k<N;k++)
		C[i][j]=C[i][j]+A[i][k]*B[k][j];
    gettime(&cpu1,&wall1) ;
    printf("cpu time = %fs\n",cpu1-cpu0);
    printf("wall time = %fs\n",wall1-wall0);
    printf("Mflops = %f\n",N*N*(2*N)/(cpu1-cpu0)*1e-6);
    return 0;
}
