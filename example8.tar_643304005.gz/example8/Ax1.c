#include<stdlib.h>
#define N 512 
int main(int argc, char *argv[])
{
    int i,j;
    double A[N][N],X[N],Y[N];
    
    for(i=0;i<N;i++)
    {
	X[i]=1.0;
	Y[i]=0.0;
	for(j=0;j<N;j++)
	    A[i][j]=1.0;
    }
    for(i=0;i<N;i++)
	for(j=0;j<N;j+=4)
	    Y[i]=Y[i]+A[i][j]*X[j]+A[i][j+1]*X[j+1]
		+A[i][j+2]*X[j+2]+A[i][j+3]*X[j+3];
    return 0;
}

