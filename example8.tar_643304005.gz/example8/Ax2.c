#include<stdlib.h>
#define N 512 
int main(int argc, char *argv[])
{
    int i,j;
    double A[N][N],X[N],Y[N];
    
    for(i=0;i<N;i++)
    {
	X[i]=1.0;
	Y[i]=0.0;
	for(j=0;j<N;j++)
	    A[i][j]=1.0;
    }
    for(i=0;i<N;i+=4)
	for(j=0;j<N;j+=4){
	    Y[i]=Y[i]+A[i][j]*X[j]+A[i][j+1]*X[j+1]
		+A[i][j+2]*X[j+2]+A[i][j+3]*X[j+3];
	    Y[i+1]=Y[i+1]+A[i+1][j]*X[j]+A[i+1][j+1]*X[j+1]
		+A[i+1][j+2]*X[j+2]+A[i+1][j+3]*X[j+3];
	    Y[i+2]=Y[i+2]+A[i+2][j]*X[j]+A[i+2][j+1]*X[j+1]
		+A[i+2][j+2]*X[j+2]+A[i+2][j+3]*X[j+3];
	    Y[i+3]=Y[i+3]+A[i+3][j]*X[j]+A[i+3][j+1]*X[j+1]
		+A[i+3][j+2]*X[j+2]+A[i+3][j+3]*X[j+3];
	}
    return 0;
}

