#include<stdio.h>
#include<omp.h>
int main(int argc, char **argv)
{
	int i, nvar=0;
#pragma omp parallel for shared(nvar)
	for (i=0;i<10;i++)
	{
#pragma omp critical
		{
			nvar+=1;
		}
	}
	printf("nvar=%d\n", nvar);
	return 0;
}
