#include<stdio.h>
#include<time.h>
#include"omp.h"
void test()
{
	int i, a = 0;
	clock_t t1,t2;
	t1=clock();
	for(i =0;i<1000000;i++)
		a=i+1;
	t2=clock();
	printf("Test time=%d\n",(t2-t1));
}
int main(int argc, char **argv)
{
	int i;
	clock_t t1,t2;
	t1=clock();
#pragma omp parallel for num_threads(2)
	for(i=0;i<2;i++)
		test();
	t2=clock();
	printf("Total test time=%d\n",(t2-t1));
	test();
	return 0;
}


