#include<stdlib.h>
#include<stdio.h>
#include<omp.h>
int main(int argc, char **argv)
{
	int seed, i;
	double pi;
	double rand_no_x,rand_no_y;
	int sum, npoints = 10000000;
#pragma pallel default(private) shared(npoints) \
		reduction(+;sum) num_threads(4)
	{
		seed=clock();
    		sum=0;
#pragma omp for
		for(i=0;i<npoints;i++){
			rand_no_x=(double)(rand_r(&seed))/(double)(RAND_MAX);
			rand_no_y=(double)(rand_r(&seed))/(double)(RAND_MAX);
			if((rand_no_x-0.5)*(rand_no_x-0.5)+(rand_no_y-0.5)*(rand_no_y-0.5)<0.25)
				sum++;
		}
	}
	pi = 4.*sum/npoints;
	printf("Pi=%f\n",pi);
	return 0;
}
