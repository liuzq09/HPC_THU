#include<stdio.h>
#include<omp.h>
int counter;
#pragma omp threadprivate(counter)
int increment_counter()
{
	counter++;
	return counter;
}
int main(int argc, char **argv)
{
#pragma omp parallel
	{
		int count;
#pragma omp single //copyprivate(counter)
		{
			counter=50;
		}
		count=increment_counter();
		printf("ThreadId:%d,counter=%d\n",omp_get_thread_num(),count);
	}
	return 1;
}
