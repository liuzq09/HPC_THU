#include<stdio.h>
#include<omp.h>
int counter;
#pragma omp threadprivate(counter)
int increment_counter()
{
	counter++;
	return counter;
}
int main(int argc, char **argv)
{
	counter=20;
#pragma omp parallel sections num_threads(2) copyin(counter)
	{
#pragma omp section
		{
			int it;
			int count1;
			for(it=0;it<100;it++)
			{
				count1=increment_counter();
			}
			printf("Id:%d, counter=%d\n",omp_get_thread_num(),count1);
		}
#pragma omp section
		{
			int it;
			int count2;
			for(it=0;it<200;it++)
			{
				count2=increment_counter();
			}
			printf("Id:%d,counter=%d\n",omp_get_thread_num(),count2);
		}
	}
	printf("main thread id:%d, counter=%d\n",omp_get_thread_num(),counter);
	return 0;
}

