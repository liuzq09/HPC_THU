#include<stdio.h>
#include "omp.h" 
static long num_steps = 100000;
double step; 
#define NUM_THREADS 4 
int main (int argc, char **argv) 
{
	int i;
	double x, sum, pi = 0.0;
	double PI25DT = 3.141592653589793238462643; 
	step = 1.0/(double) num_steps; 
#pragma omp parallel private(i, x, sum) num_threads(NUM_THREADS)
	{
		for (i=omp_get_thread_num(),sum=0.0;i<num_steps; i+=NUM_THREADS){
			x = (i+0.5)*step;
			sum = sum + 4.0/(1.0+x*x); 
		}
#pragma omp critical
		pi =pi + step * sum;
	}
	printf("Pi=%.16f,error=%.16f\n",pi, pi-PI25DT);
 	return 0;	
} 
