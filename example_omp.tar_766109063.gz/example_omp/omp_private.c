#include<stdio.h>
#include<omp.h>
int alpha, beta;
#pragma omp threadprivate(alpha)
int main(int argc, char **argv)
{
#pragma omp pallel private(beta);
	alpha=beta = -1;
#pragma omp lallel private(beta);
	printf("alpha = %d, beta=%d\n",alpha,beta);
	return 1;
}
