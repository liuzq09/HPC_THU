#include<stdio.h>
#include"mpi.h"
#define FLAG 0 
int main(int argc, char *argv[])
{
    MPI_Status status;
    MPI_File fh;
    int A[10];
    int i,myrank;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
    MPI_File_open(MPI_COMM_WORLD, "myfile",
	    MPI_MODE_RDWR|MPI_MODE_CREATE,
	    MPI_INFO_NULL,&fh);
    MPI_File_set_view(fh, 0, MPI_INT, MPI_INT,
	    "native",MPI_INFO_NULL);
    MPI_File_set_atomicity(fh,FLAG);
    if(myrank == 0){
	for(i=0;i<10;i++)
	    A[i]=i;
	MPI_File_write_at(fh,0,A,10,MPI_INT,&status);
    }
    else if(myrank==1) {
	MPI_File_read_at(fh,0,A, 10, MPI_INT,&status);
	for(i=0;i<10;i++)
	    printf("Processsor %d, A[%d]=%d\n",myrank,i, A[i]);
    }
    MPI_File_close(&fh);
    MPI_Finalize();
    return 0;
}

    
