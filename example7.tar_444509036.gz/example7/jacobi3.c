/* nprocs:           total number of processors 
 * np, nq:           processor grid, np*nq = nprocs
 * comm  :           communicator with 2d cartesian topology
 * rank_x, rank_y:   Cartesian coordinates in comm
 * myrank:           my rank in comm
 * nglob, mglob:     total grid points
 * nloca, mloca:     local grid points
 * ioffset, joffset: coordinates of lower-left corner in the global grid*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include"mpi.h"
#define TRUE 1
#define FALSE 0
#define MAX(a,b) ((a)<(b)?(b):(a))

int main(int argc, char *argv[])
{
    int nprocs, np, nq, myrank;
    int nglob, mglob;
    int nloca,mloca;
    MPI_Comm comm,comm_x,comm_y;
    int rank_x, rank_y, ioffset, joffset;
    int left, right, lower, upper;
    MPI_Datatype T1, T2;
    MPI_Status status;

    double **F,**u,**ua,**unew;
    double t0,t1;
    double a, b;
    double x, y;
    double dx, dy, d,hx,hy;
    double res0, res,residual;
    double err0, err;
    int ntmp,mtmp;
    int i,j, it, nit;
    int I,J,N,M;

    /*for parallel I/O*/
    MPI_File fh;
    MPI_Datatype filetype, memtype;
    int mode;
    int sizes[2], subsizes[2],starts[2];
    int I1, I2, J1, J2;

    int dims[2];
    int periods[2],reorder;

    periods[0]=FALSE;
    periods[1]=FALSE;
    reorder=TRUE;

    MPI_Init(&argc, &argv);

    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
    MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
    if(myrank == 0){
	a=1.;	b=1.;
	np=3,nq=3;
	dims[0]=np,dims[1]=nq;
	printf("Enter nglob, mglob, nit \n");
	scanf("%d %d %d",&nglob, &mglob,&nit);
    }
    MPI_Bcast(&a, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&b, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&nglob, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&mglob, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&nit, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(dims, 2, MPI_INT, 0, MPI_COMM_WORLD);
    np = dims[0];
    nq = dims[1];
    
    MPI_Cart_create(MPI_COMM_WORLD, 2, dims, periods, reorder,&comm);

    periods[0]=TRUE;
    periods[1]=FALSE;

    MPI_Cart_sub(comm, periods, &comm_x);
    MPI_Comm_rank(comm_x, &rank_x);
    periods[0]=FALSE;
    periods[1]=TRUE;
    MPI_Cart_sub(comm, periods,&comm_y);
    MPI_Comm_rank(comm_y, &rank_y);
    /*Compute local N: block distribution of interior grid points.*/
    I= (nglob-1)/np;
    if(rank_x< (nglob-1)%np)
	nloca = I+2;
    else
	nloca = I+1;

    J= (mglob-1 )/nq;
    if (rank_y<(mglob-1)%nq)
	mloca = J+2;
    else
	mloca = J+1;
    /*Compute coordinates of lower-left corner of the subdomain using 
     * MPI_Scan */
//    printf("nloca=%d,mlocal=%d\n",nloca,mloca);
    ntmp=nloca -1;
    MPI_Scan(&ntmp, &ioffset,1,MPI_INT, MPI_SUM, comm_x);
    ioffset=ioffset-ntmp;
    mtmp=mloca -1;
    MPI_Scan(&mtmp, &joffset, 1, MPI_INT, MPI_SUM, comm_y);
    joffset=joffset - mtmp;
//    printf("ioffset=%d, joffset=%d\n",ioffset, joffset);

    MPI_Comm_free(&comm_x);
    MPI_Comm_free(&comm_y);

    N=nloca;
    M=mloca;
    
    F=(double **)malloc((N+1)*sizeof(double*));
    u=(double **)malloc((N+1)*sizeof(double*));
    ua=(double **)malloc((N+1)*sizeof(double*));
    unew=(double **)malloc((N+1)*sizeof(double*));
    F[0]=(double*)malloc((M+1)*(N+1)*sizeof(double));
    u[0]=(double*)malloc((M+1)*(N+1)*sizeof(double));
    ua[0]=(double*)malloc((M+1)*(N+1)*sizeof(double));
    unew[0]=(double*)malloc((M+1)*(N+1)*sizeof(double));
    for(i=1;i<N+1;i++){
	F[i]=F[0]+i*(M+1);
	u[i]=u[0]+i*(M+1);
	ua[i]=ua[0]+i*(M+1);
	unew[i]=unew[0]+i*(M+1);
    }
   
    /*Initialzie the solution and boundary condition*/

    hx = a/(nglob);
    hy = b/(mglob);

    dx = 1./(hx*hx);
    dy = 1./(hy*hy);
    d = 1./(dx+dx+dy+dy);

    /*Analytical solution*/
    for(i=0;i<=N;i++)
	for(j=0;j<=M;j++){
	    x=(i+ioffset)*hx;
	    y=(j+joffset)*hy;
	    ua[i][j]=-0.25*(x*x+y*y);
	}
    /*Initial approximation and RHS*/
    for(i=0;i<=N;i++)
	for(j=0;j<=M;j++)
	{
	    F[i][j]=1.0*d;
	    u[i][j]=0.0;
	}
    /*boundary coorditions*/
    if(rank_y == 0)
	for(i=0;i<=N;i++)
	    u[i][0] = ua[i][0];
    if(rank_y == nq-1)
	for(i=0;i<=N;i++)
	    u[i][M]=ua[i][M];
    if(rank_x == 0)
	for(j=0;j<=M;j++)
    	    u[0][j]=ua[0][j];
    if(rank_x == np-1)
	for(j=0;j<=M;j++)
	    u[N][j]=ua[N][j];
    /*Jacobi iteration*/
    dx=dx*d;
    dy=dy*d;
    MPI_Cart_shift(comm,0,1, &left, &right);
    MPI_Cart_shift(comm,1,1,&lower, &upper);

    /*Create datatype T1 for one col of u(x-direction) 
     * and T2 for one row of u (y-direction)*/
    MPI_Type_vector(N-1, 1, M+1, MPI_DOUBLE, &T1);
    MPI_Type_commit(&T1);
    MPI_Type_contiguous(M-1, MPI_DOUBLE, &T2);
    MPI_Type_commit(&T2);
    t0 = MPI_Wtime();
    /*Jacobi iteration loop*/
    for(it = 1; it<=nit;it++){
    	for(i=1;i<N;i++)
    	    for(j=1;j<M;j++)
    		unew[i][j]=F[i][j]+dx*(u[i-1][j]+u[i+1][j])
    		    +dy*(u[i][j-1]+u[i][j+1]);
    	for(i=1;i<N;i++)
    	    for(j=1;j<M;j++)
    		u[i][j]=unew[i][j];
    	/*update the inner boundary values:u[1:N-1][1]->lower,u[1:N-1][M]<-upper*/
    	MPI_Sendrecv(&u[1][1],1,T1, lower, 111,
    		&u[1][M],1, T1, upper, 111, comm, &status);
    	/*update the inner boundary values:u[1:N-1][M-1]->upper,u[1:N-1][0]<-lower*/
    	MPI_Sendrecv(&u[1][M-1],1,T1,upper,111,
     		&u[1][0],1,T1,lower,111, comm, &status);
    	/*update inner boundary values:u[1][1:M-1]->left,u[N][1:M-1]<-right*/
    	MPI_Sendrecv(&u[1][1],1, T2, left, 111,
    		&u[N][1],1, T2, right, 111, comm, &status);
    	/*update inner boundary values:u[N-1][1:M-1]->right,u[0][1:M-1]<-left*/
    	MPI_Sendrecv(&u[N-1][1],1,T2,right,111,
    		&u[0][1],1,T2, left, 111, comm,&status);
	
    	/*Compute residual*/
    	res0=0.0;
    	for(i=1;i<N;i++)
    	    for(j=1;j<M;j++){
    		res = F[i][j]-u[i][j]+dx*(u[i+1][j]+u[i-1][j])+
    		    dy*(u[i][j+1]+u[i][j-1]);
    		res0=MAX(res0,fabs(res));
    	    }
    	MPI_Reduce(&res0, &residual, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    //	if(myrank == 0&&it%1000==0)
    //	    printf("It = %d, residual =%f\n", it, residual/d);
    }
    /*parallel I/O*/
    /*define the datatype of subarray*/
    /*rank_x=0    => I1=0*/
    /*rank_x>=1   => I1=1*/
    /*rank_x=np-1 => I2=0*/
    /*rank_x<np-1 => I2=1*/
    I1 = (rank_x+np-1)/np;
    I2=1-(rank_x+1)/np;
    J1=(rank_y+nq-1)/nq;
    J2=1-(rank_y+1)/nq;
    sizes[0]=nglob+1;
    sizes[1]=mglob+1;
    starts[0]=ioffset + I1;/*ignoring the ghost points*/
    starts[1]=joffset + J1;/*ignoring the ghost points*/
    subsizes[0]=N-I2-I1+1; /*N for boundary subarray,N-1 for interior subarray*/
    subsizes[1]=M-J2-J1+1; /*M for boubdary subarray,M-1 for interior subarray*/
    MPI_Type_create_subarray(2,sizes,subsizes,starts,
	    MPI_ORDER_C, MPI_DOUBLE, &filetype);
    MPI_Type_commit(&filetype);
    
    /*define datatype to describe the distribution of subarray in mem*/
    sizes[0]=N+1;
    sizes[1]=M+1;
    starts[0]=I1;/*from 0 for left boundary and from 1 for others*/
    starts[1]=J1;/*from 0 for lower boundary and from 1 for others*/
    MPI_Type_create_subarray(2,sizes,subsizes,starts,
	    MPI_ORDER_C, MPI_DOUBLE, &memtype);
    MPI_Type_commit(&memtype);

    mode = MPI_MODE_WRONLY|MPI_MODE_CREATE;
    if((MPI_File_open(comm,"jacobi.tmp",mode,
		    MPI_INFO_NULL,&fh))!=MPI_SUCCESS)
    {
	printf("%d cannot open output file 'jacobi.tmp'\n",myrank);
	MPI_Abort(comm, 2);
    }
    MPI_File_set_view(fh, 0, MPI_DOUBLE, filetype, "native",
	    MPI_INFO_NULL);
    MPI_File_write_all(fh, u, 1, memtype, &status);
    MPI_Type_free(&filetype);
    MPI_Type_free(&memtype);
    MPI_File_close(&fh);
    if(myrank ==0)
	system("mv -f jacobi.tmp jacobi.dat");
    
    MPI_Type_free(&T1);
    MPI_Type_free(&T2);
    
    t1=MPI_Wtime();
    if(myrank == 0)
	printf("Wall time = %f\n",t1-t0);
    /*check for convergence*/
    err0 = 0.0;
    for(i=1;i<N;i++)
	for(j=1;j<M;j++)
	    err0=MAX(err0,fabs(u[i][j]-ua[i][j]));
    
    MPI_Reduce(&err0, &err,1,MPI_DOUBLE,MPI_MAX,0,
	    MPI_COMM_WORLD);
    if(myrank == 0)
	printf("Error= %f\n",err);
    free(F[0]);	free(u[0]); free(ua[0]); free(unew[0]);
    free(F);free(u);free(ua);free(unew);
    MPI_Finalize();
    return 0;
}

