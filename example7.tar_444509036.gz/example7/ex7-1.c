#include<stdio.h>
#include"mpi.h"
int main(int argc, char *argv[])
{
    MPI_Status status;
    MPI_File fh;
    int myrank, mode;
    int A;
    int B;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
    A=myrank;

    mode = MPI_MODE_RDWR|MPI_MODE_CREATE;
    MPI_File_open(MPI_COMM_WORLD, "testfile", mode,
	    MPI_INFO_NULL, &fh);
    MPI_File_set_view(fh, 0, MPI_INT, MPI_INT,
	    "native", MPI_INFO_NULL);
//    MPI_File_write_shared(fh, &A, 1, MPI_INT, &status);
    MPI_File_write_ordered(fh, &A, 1, MPI_INT, &status);
    MPI_File_close(&fh);
    mode = MPI_MODE_RDONLY|MPI_MODE_DELETE_ON_CLOSE;
    MPI_File_open(MPI_COMM_WORLD, "testfile",mode,
	    MPI_INFO_NULL, &fh);
    MPI_File_set_view(fh, 0, MPI_INT, MPI_INT,
	    "native",MPI_INFO_NULL);
    MPI_File_read_ordered(fh, &B, 1, MPI_INT, &status);
    printf("Proc %d reads B=%d\n",myrank, B);
    MPI_File_close(&fh);
    MPI_Finalize();
    return 0;
}



