/* nprocs = 4 */
/* nprocs:           total number of processors 
 * np, nq:           processor grid, np*nq = nprocs
 * comm  :           communicator with 2d cartesian topology
 * rank_x, rank_y:   Cartesian coordinates in comm
 * myrank:           my rank in comm
 * nglob, mglob:     total grid points
 * nloca, mloca:     local grid points
 * ioffset, joffset: coordinates of lower-left corner in the global grid*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include"mpi.h"
#define MAX(a,b) ((a)<(b)?(b):(a))

int main(int argc, char *argv[])
{
    int nprocs, np, nq, myrank;
    int nglob, mglob;
    int nloca,mloca;
    MPI_Comm comm,comm_x,comm_y;
    int rank_x, rank_y, ioffset, joffset;
    int left, right, lower, upper;
    MPI_Datatype T1, T2;
    MPI_Status status;

    double **F,**u,**ua,**unew;
    double t0,t1;
    double a, b;
    double x, y;
    double dx, dy, d,hx,hy;
    double res0, res,residual;
    double err0, err;
    int ntmp,mtmp;
    int i,j, it, nit;
    int I,J,N,M;

    int dims[2];
    int color,key;

    MPI_Init(&argc, &argv);

    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
    MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
    if(myrank == 0){
	a=1.;	b=1.;
	nit = 10000; np=2,nq=2;
	dims[0]=np,dims[1]=nq;
	nglob = 100;
	mglob = 100;
    }
    MPI_Bcast(&a, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&b, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&nglob, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&mglob, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&nit, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(dims, 2, MPI_INT, 0, MPI_COMM_WORLD);
    np = dims[0];
    nq = dims[1];
/*Construct comm_x*/
    color = myrank/np;
    key = myrank;
    MPI_Comm_split(MPI_COMM_WORLD, color, key, &comm_x);
    MPI_Comm_rank(comm_x,&rank_x);
/*Construct comm_y*/
    color = myrank%np;
    key = myrank;
    MPI_Comm_split(MPI_COMM_WORLD, color, key, &comm_y);
    MPI_Comm_rank(comm_y,&rank_y);

    /*Compute local N: block distribution of interior grid points.*/
    I= (nglob-1)/np;
    if(rank_x< (nglob-1)%np)
	nloca = I+2;
    else
	nloca = I+1;

    J= (mglob-1 )/nq;
    if (rank_y<(mglob-1)%nq)
	mloca = J+2;
    else
	mloca = J+1;
    /*Compute coordinates of lower-left corner of the subdomain using 
     * MPI_Scan */
    //printf("nloca=%d,mlocal=%d\n",nloca,mloca);
    ntmp=nloca -1;
    MPI_Scan(&ntmp, &ioffset,1,MPI_INT, MPI_SUM, comm_x);
    ioffset=ioffset-ntmp;
    mtmp=mloca -1;
    MPI_Scan(&mtmp, &joffset, 1, MPI_INT, MPI_SUM, comm_y);
    joffset=joffset - mtmp;
    //printf("ioffset=%d, joffset=%d\n",ioffset, joffset);

    N=nloca;
    M=mloca;
    
    F=(double **)malloc((N+1)*sizeof(double*));
    u=(double **)malloc((N+1)*sizeof(double*));
    ua=(double **)malloc((N+1)*sizeof(double*));
    unew=(double **)malloc((N+1)*sizeof(double*));
    F[0]=(double*)malloc((M+1)*(N+1)*sizeof(double));
    u[0]=(double*)malloc((M+1)*(N+1)*sizeof(double));
    ua[0]=(double*)malloc((M+1)*(N+1)*sizeof(double));
    unew[0]=(double*)malloc((M+1)*(N+1)*sizeof(double));
    for(i=1;i<N+1;i++){
	F[i]=F[0]+i*(M+1);
	u[i]=u[0]+i*(M+1);
	ua[i]=ua[0]+i*(M+1);
	unew[i]=unew[0]+i*(M+1);
    }
   
    /*Initialzie the solution and boundary condition*/

    hx = a/(nglob);
    hy = b/(mglob);

    dx = 1./(hx*hx);
    dy = 1./(hy*hy);
    d = 1./(dx+dx+dy+dy);

    /*Analytical solution*/
    for(i=0;i<=N;i++)
	for(j=0;j<=M;j++){
	    x=(i+ioffset)*hx;
	    y=(j+joffset)*hy;
	    ua[i][j]=-0.25*(x*x+y*y);
	}
    /*Initial approximation and RHS*/
    for(i=0;i<=N;i++)
	for(j=0;j<=M;j++)
	{
	    F[i][j]=1.0*d;
	    u[i][j]=0.0;
	}
    /*boundary coorditions*/
    if(rank_y == 0)
	for(i=0;i<=N;i++)
	    u[i][0] = ua[i][0];
    if(rank_y == nq-1)
	for(i=0;i<=N;i++)
	    u[i][M]=ua[i][M];
    if(rank_x == 0)
	for(j=0;j<=M;j++)
    	    u[0][j]=ua[0][j];
    if(rank_x == np-1)
	for(j=0;j<=M;j++)
	    u[N][j]=ua[N][j];
    /*Jacobi iteration*/
    dx=dx*d;
    dy=dy*d;
    left = rank_x -1;
    if(left<0)
	left=MPI_PROC_NULL;
    right=rank_x + 1;
    if(right>=np)
	right = MPI_PROC_NULL;
    lower = rank_y -1;
    if(lower<0)
	lower=MPI_PROC_NULL;
    upper = rank_y +1;
    if(upper >=nq)
	upper = MPI_PROC_NULL;


    /*Create datatype T1 for one col of u(x-direction) 
     * and T2 for one row of u (y-direction)*/
    MPI_Type_vector(N-1, 1, M+1, MPI_DOUBLE, &T1);
    MPI_Type_commit(&T1);
    MPI_Type_contiguous(M-1, MPI_DOUBLE, &T2);
    MPI_Type_commit(&T2);

    t0 = MPI_Wtime();
    /*Jacobi iteration loop*/
    for(it = 1; it<=nit;it++){
    	for(i=1;i<N;i++)
    	    for(j=1;j<M;j++)
    		unew[i][j]=F[i][j]+dx*(u[i-1][j]+u[i+1][j])
    		    +dy*(u[i][j-1]+u[i][j+1]);
    	for(i=1;i<N;i++)
    	    for(j=1;j<M;j++)
    		u[i][j]=unew[i][j];
    	/*update the inner boundary values:u[1:N-1][1]->lower,u[1:N-1][M]<-upper*/
    	MPI_Sendrecv(&u[1][1],1,T1, lower, 111,
    		&u[1][M],1, T1, upper, 111, comm_y, &status);
    	/*update the inner boundary values:u[1:N-1][M-1]->upper,u[1:N-1][0]<-lower*/
    	MPI_Sendrecv(&u[1][M-1],1,T1,upper,111,
     		&u[1][0],1,T1,lower,111, comm_y, &status);
    	/*update inner boundary values:u[1][1:M-1]->left,u[N][1:M-1]<-right*/
    	MPI_Sendrecv(&u[1][1],1, T2, left, 111,
    		&u[N][1],1, T2, right, 111, comm_x, &status);
    	/*update inner boundary values:u[N-1][1:M-1]->right,u[0][1:M-1]<-left*/
    	MPI_Sendrecv(&u[N-1][1],1,T2,right,111,
    		&u[0][1],1,T2, left, 111, comm_x, &status);
	
    	/*Compute residual*/
    	res0=0.0;
    	for(i=1;i<N;i++)
    	    for(j=1;j<M;j++){
    		res = F[i][j]-u[i][j]+dx*(u[i+1][j]+u[i-1][j])+
    		    dy*(u[i][j+1]+u[i][j-1]);
    		res0=MAX(res0,fabs(res));
    	    }
    	MPI_Reduce(&res0, &residual, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    	if(myrank == 0&&it%1000==0)
    	    printf("It = %d, residual =%f\n", it, residual/d);
    }
    MPI_Type_free(&T1);
    MPI_Type_free(&T2);
    
    t1=MPI_Wtime();
    if(myrank == 0)
	printf("Wall time = %f\n",t1-t0);
    /*check for convergence*/
    err0 = 0.0;
    for(i=1;i<N;i++)
	for(j=1;j<M;j++)
	    err0=MAX(err0,fabs(u[i][j]-ua[i][j]));
    
    MPI_Reduce(&err0, &err,1,MPI_DOUBLE,MPI_MAX,0,
	    MPI_COMM_WORLD);
    if(myrank == 0)
	printf("Error= %f\n",err);
    free(F[0]);	free(u[0]); free(ua[0]); free(unew[0]);
    free(F);free(u);free(ua);free(unew);
    MPI_Finalize();
    return 0;
}   
