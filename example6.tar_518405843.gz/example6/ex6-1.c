#include<stdio.h>
#include"mpi.h"
int main(int argc, char *argv[])
{
    MPI_Comm comm;
    int result;
    MPI_Init(&argc, &argv);
    MPI_Comm_dup(MPI_COMM_WORLD, &comm);
    MPI_Comm_compare(MPI_COMM_WORLD, comm, &result);
    if(result == MPI_IDENT)
	printf("The two communicators are identical.\n");
    else if(result == MPI_CONGRUENT)
	printf("The two communicators are congruent.\n");
    else if(result == MPI_SIMILAR)
        printf("The two communicators are similar.\n");
    else if(result == MPI_UNEQUAL)
	printf("The two communicators are unequal.\n");
    else 
	printf("Unknown result.\n");

    MPI_Finalize();
    return 0;
}
