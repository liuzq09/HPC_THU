#include<stdio.h>
#include"mpi.h"
int main(int argc, char *argv[])
{
    int myrank, srank;
    MPI_Group MPI_GROUP_WORLD, grprem;
    MPI_Comm commslave;
    static int ranks[] = {0};
    double a=1.0;
    double sum,sum1;

    MPI_Init(&argc, &argv);
    MPI_Comm_group(MPI_COMM_WORLD, &MPI_GROUP_WORLD);
    MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
    MPI_Group_excl(MPI_GROUP_WORLD, 1, ranks,&grprem);
    MPI_Comm_create(MPI_COMM_WORLD, grprem, &commslave);
//        MPI_Comm_rank(commslave,&srank);
    if(myrank != 0){
	/*compute on slave*/
        MPI_Comm_rank(commslave,&srank);
	sum = 0.0;
	MPI_Reduce(&a,&sum, 1, MPI_DOUBLE, MPI_SUM, 0, commslave);
        MPI_Comm_free(&commslave);
	printf("Sum result on processor %d(rank in slave comm is %d) is %f\n",myrank,srank, sum);
    }
    sum1 = 0.0;
    MPI_Reduce(&a,&sum1,1,MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    if(myrank == 0)
	printf("Sum result on processor %d is %f\n",myrank, sum1);
    MPI_Group_free(&MPI_GROUP_WORLD);
    MPI_Group_free(&grprem);
    MPI_Finalize();
    return 0;
}
