#include<stdio.h>
#include<time.h>
#include<math.h>
#define MAX(a,b) ((a)<(b)?(b):(a))
#define N 200
#define M 200
double elapsed_time(void)
{
    clock_t t;
    t=clock();
    return t/CLOCKS_PER_SEC;
}

int main(int argc, char argv[])
{
    double a,b;
    int i,j,it, nit;
    double F[N+1][M+1],u[N+1][M+1];
    double unew[N+1][M+1],ua[N+1][M+1];

    double t0,t1;
    double x,y,hx,hy,dx,dy,d;
    double err0,err, res, residual;

    nit = 10000;
    a=b=1.0;
    hx=a/N;
    hy=b/M;
    dx=1./(hx*hx);
    dy=1./(hy*hy);
    d=1./(dx+dx+dy+dy);
    printf("hx=%f,hy=%f,d=%f\n",hx,hy,d);

// Analytical solution
    for(i=0;i<=N;i++)
	for(j=0;j<=M;j++)
	{
	    x=i*hx;
	    y=j*hy;
   	    ua[i][j] = -0.25*( x*x + y*y );
	    F[i][j]=0.0;
	}
/* Initial approximation and RHS*/
      for(i=1;i<N;i++)
	  for(j=1;j<M;j++){
	      F[i][j]=1.0*d;
	      u[i][j]=0.0;
	  }
/* Boundary condition*/
      for(i=0;i<=N;i++)
      {
	  u[i][0]=ua[i][0];
          u[i][M]=ua[i][M];
      }
      for(j=0;j<=M;j++){
 	  u[0][j]=ua[0][j];
	  u[N][j]=ua[N][j];
      }
      dx = dx *d;
      dy = dy *d;
      t0=elapsed_time();  
      for(it=1;it<nit;it++){
	  for(i=1;i<N;i++)
	      for(j=1;j<M;j++){
		  unew[i][j]=F[i][j]+dx*(u[i-1][j]+u[i+1][j])
		      +dy*(u[i][j+1]+u[i][j-1]);
	      }
	  for(i=1;i<N;i++)
	      for(j=1;j<M;j++)
		  u[i][j]=unew[i][j];
/* Compute residual*/
         residual=0.;
	 for(i=1;i<N;i++)
	     for(j=1;j<M;j++){
		 res = F[i][j]-u[i][j]+dx*(u[i+1][j]+u[i-1][j])
		     +dy*(u[i][j+1]+u[i][j-1]);
		 residual = MAX(residual, fabs(res));
	     }
	 if(it%100==0)
    	     printf("It = %d, Residual = %f\n",it, residual/d);
      }
      t1=elapsed_time();
/* Compute Linfty(error)*/
      err = 0;
      for(i=1;i<N;i++)
	  for(j=1;j<M;j++)
	      err= MAX(err, fabs(u[i][j]-ua[i][j]));
      printf("Error = %f,Elapsed time =%f\n",err,t1-t0);
      return 0;
}
	    
