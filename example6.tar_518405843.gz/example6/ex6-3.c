/* Number of process > 8 */
#include<stdio.h>
#include"mpi.h"
#define TAG_ARBITRARY 12345
#define SOME_COUNT 50
int main(int argc, char *argv[])
{
    int myrank;
    MPI_Request request[2];
    MPI_Group MPI_GROUP_WORLD, subgroup;
    int ranks[]={2,4,6,8};
    MPI_Comm the_comm;
    MPI_Status status;
    double buf1,buf2;
    double sum;
    buf1=0.0;
    buf2=1.0;
    

    MPI_Init(&argc, &argv);
    MPI_Comm_group(MPI_COMM_WORLD, &MPI_GROUP_WORLD);
    MPI_Group_incl(MPI_GROUP_WORLD,4,ranks, &subgroup);
    MPI_Group_rank(subgroup, &myrank);

    MPI_Comm_create(MPI_COMM_WORLD, subgroup, &the_comm);

    if(myrank !=MPI_UNDEFINED)
    {
	MPI_Irecv(&buf1,1,MPI_DOUBLE, MPI_ANY_SOURCE, TAG_ARBITRARY,
		the_comm,request);
	MPI_Isend(&buf2,1,MPI_DOUBLE, myrank%4,TAG_ARBITRARY,
		the_comm,request+1);
	MPI_Waitall(2,request,&status);
        MPI_Reduce(&buf1,&sum,1,MPI_DOUBLE,MPI_SUM,0,the_comm);
	printf("Sum on processor %d of the comm is %f\n",myrank, sum);
	MPI_Comm_free(&the_comm);
    }
    MPI_Group_free(&MPI_GROUP_WORLD);
    MPI_Group_free(&subgroup);
    MPI_Finalize();
    return 0;
}
