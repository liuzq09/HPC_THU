/*For the operation concerning group of process*/
#include<stdio.h>
#include"mpi.h"
int main(int argc, char *argv[])
{
    int myrank, srank;
    MPI_Group MPI_GROUP_WORLD, grprem;
    static int ranks[] = {0};
    double a=1.0;

    MPI_Init(&argc, &argv);
    MPI_Comm_group(MPI_COMM_WORLD, &MPI_GROUP_WORLD);
    MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
    MPI_Group_excl(MPI_GROUP_WORLD, 1, ranks,&grprem);
    MPI_Group_rank(grprem,&srank);
    if(myrank != 0){
	/*compute on slave*/
	printf("Processor %d in slave comm is %d\n",myrank,srank);
    }
    MPI_Group_free(&MPI_GROUP_WORLD);
    MPI_Group_free(&grprem);
    MPI_Finalize();
    return 0;
}
