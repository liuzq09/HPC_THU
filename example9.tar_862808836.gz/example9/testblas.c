#include<stdio.h>
extern double ddot_(int * , double *,int *, double *, int *);
int main(int argc, char *argv[])
{
    double x[5],y[5];
    int i,n;
    int incx,incy;
    double sum=0.;
    for(i=0;i<5;i++){
	x[i]=i+1.;
	y[i]=i+5.;
    }
    n=5,incx=1,incy=1;
    for(i=0;i<5;i++)
	    sum+=x[i]*y[i];
    printf("The inner product is %f\n",sum);
    sum = ddot_(&n,x,&incx,y,&incy);
    printf("The inner product is %f\n",sum);
    return 0;
}
